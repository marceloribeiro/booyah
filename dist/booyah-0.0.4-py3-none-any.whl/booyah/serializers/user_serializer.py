from booyah.serializers.application_serializer import ApplicationSerializer

class UserSerializer(ApplicationSerializer):
    pass