from booyah.controllers import BooyahApplicationController

class ApplicationController(BooyahApplicationController):
    pass