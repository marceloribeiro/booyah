from booyah.bin.booyah import run

def main():
    print('Running main()')
    run()

if __name__ == "__main__":
    main()
