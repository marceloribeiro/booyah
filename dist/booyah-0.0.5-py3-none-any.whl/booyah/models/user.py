from booyah.models.application_model import ApplicationModel

class User(ApplicationModel):
    pass