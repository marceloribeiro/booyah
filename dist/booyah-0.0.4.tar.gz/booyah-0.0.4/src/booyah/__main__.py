from booyah.bin.booyah import run
run()
