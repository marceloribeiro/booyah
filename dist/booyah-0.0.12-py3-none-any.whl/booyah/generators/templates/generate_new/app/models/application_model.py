from booyah.models import BooyahApplicationModel

class ApplicationModel(BooyahApplicationModel):
    pass